GLOBAL RANKING eFOOTBALL — ANDROID APP PROJECT

Aplikasi Android ini membungkus aplikasi ranking eFootball dalam WebView.
Fitur aplikasi (ranking, tambah/edit/hapus negara, pertandingan, sistem poin,
riwayat, export/import JSON) disediakan oleh app/src/main/assets/index.html.
Penyimpanan localStorage aktif di WebView.

CARA MEMBUAT APK TANPA MEMASANG ANDROID STUDIO DI HP:
1. Masuk ke https://github.com dan buat akun/login.
2. Buat repository baru bernama GlobalRankingEfootball.
3. Ekstrak ZIP project ini di komputer atau gunakan fitur upload files di GitHub
   untuk mengunggah semua isi folder project ke root repository.
4. Pastikan folder .github/workflows/build-apk.yml ikut terunggah.
5. Buka tab Actions di repository. Pilih "Build Android APK", lalu tekan
   "Run workflow" (atau tunggu build otomatis setelah push ke branch main).
6. Setelah workflow selesai dengan status hijau, buka run tersebut.
7. Di bagian Artifacts, unduh "GlobalRanking-eFootball-APK".
8. Ekstrak ZIP artifact, lalu buka app-debug.apk di HP Android untuk memasang.
   Android mungkin meminta izin "Install unknown apps" untuk aplikasi/browser
   yang digunakan. Aktifkan hanya jika kamu yakin file berasal dari repository-mu.

CATATAN:
- APK debug cocok untuk penggunaan pribadi dan uji coba.
- Data disimpan lokal pada perangkat. Menghapus data aplikasi atau uninstall
  dapat menghapus data; gunakan Export Data sebagai cadangan.
- Ini bukan aplikasi resmi FIFA. Ranking dan poin awal adalah data simulasi
  untuk eFootball, bukan ranking resmi FIFA.
